﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma.Helpers
{
    public class MessengerNumberMessage<NumerousType>
    {
        public NumerousType Number { get; set; }
    }
}
