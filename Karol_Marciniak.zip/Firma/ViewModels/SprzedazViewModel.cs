﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma.ViewModels
{
    internal class SprzedazViewModel : WorkspaceViewModel
    {
        #region Konstruktor
        public SprzedazViewModel()
        {
            base.DisplayName = "Sprzedaż";
        }
        #endregion
    }
}
