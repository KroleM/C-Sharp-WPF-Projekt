﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma.ViewModels
{
    public class WszystkieFakturyViewModel: WorkspaceViewModel
    {
        #region Konstruktor
        public WszystkieFakturyViewModel()
        {
            base.DisplayName = "Wszystkie faktury"; //tu ustawiamy nazwę zakładki
        }
        #endregion
    }
}
