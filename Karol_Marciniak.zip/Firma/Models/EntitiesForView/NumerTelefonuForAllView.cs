﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma.Models.EntitiesForView
{
    public class NumerTelefonuForAllView : BaseForAllView
    {
        #region Properties
        public string Numer { get; set; }
        public string Kraj { get; set; }
        public string Pracownik { get; set; }
        #endregion
    }
}
