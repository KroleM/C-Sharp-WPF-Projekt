﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma.Models.EntitiesForView
{
    public class ComboBoxKeyAndValue
    {
        public int Key { get; set; }
        public string Value { get; set; }
    }
    // Ta klasa mogłaby być 'bardziej' generyczna - przyjmować 2 dowolne typy danych, aby potem je wyświetlać;
}
